#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/Users/dalason/Documents/iPhone_Development/linphoneJune/linphone-iphone/submodules/build/..//../liblinphone-sdk/i386-apple-darwin/lib"
XML2_LIBS="-lxml2  -lpthread  -lm "
XML2_INCLUDEDIR="-I/Users/dalason/Documents/iPhone_Development/linphoneJune/linphone-iphone/submodules/build/..//../liblinphone-sdk/i386-apple-darwin/include/libxml2"
MODULE_VERSION="xml2-2.8.0"

